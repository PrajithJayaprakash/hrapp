import LandingPage from "@/components/landing/LandingPage";
import Image from "next/image";

export default function Home() {
  return (
    <>
    <LandingPage />
    </>
  );
}
